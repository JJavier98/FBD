DROP TABLE satelite;
DROP TABLE planeta;
DROP TABLE forman;
DROP TABLE estrella;
DROP TABLE constelacion;
DROP TABLE objeto_astronomico;