DROP TABLE libro;
DROP TABLE ejemplar;
DROP TABLE usuario;
DROP TABLE autor;
DROP TABLE escrito;
DROP TABLE tema;
DROP TABLE prestamo;