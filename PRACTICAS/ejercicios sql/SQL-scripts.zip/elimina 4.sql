DROP TABLE formado
DROP TABLE p_compuesta
DROP TABLE p_simple
DROP TABLE pieza