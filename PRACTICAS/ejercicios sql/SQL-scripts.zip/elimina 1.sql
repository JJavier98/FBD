DROP TABLE vinculada
DROP TABLE titular
DROP TABLE cuenta_corriente
DROP TABLE titular
DROP TABLE tarjeta