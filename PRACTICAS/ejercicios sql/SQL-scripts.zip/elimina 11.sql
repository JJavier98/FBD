drop table Referencia;
drop table Escribe;
drop table Articulo;
drop table Numero;
drop table Revista;
drop table Autor;