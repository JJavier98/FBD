drop table Tarjeta_embarque;
drop table Vuelo;
drop table Asiento;
drop table Avion;
drop table Pasajero;
drop table Destino;
drop table Trayecto;