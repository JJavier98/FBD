DROP TABLE peliculas;
DROP TABLE cintas;
DROP TABLE cliente5;
DROP TABLE prestamo5;