DROP TABLE alquiler;
DROP TABLE habitacion;
DROP TABLE piso;
DROP TABLE un_local;
DROP TABLE cliente;
DROP TABLE inmueble;