DROP TABLE portatil;
DROP TABLE pc;
DROP TABLE impresora;
DROP TABLE producto;