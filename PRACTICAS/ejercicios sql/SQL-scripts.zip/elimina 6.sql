DROP TABLE personaempresa;
DROP TABLE factura;
DROP TABLE linea;
DROP TABLE articulo;
DROP TABLE emite;
DROP TABLE recibe;