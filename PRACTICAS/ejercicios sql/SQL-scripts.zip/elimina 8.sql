DROP TABLE entrada;
DROP TABLE proyeccion;
DROP TABLE copia;
DROP TABLE asiento;
DROP TABLE pelicula;
DROP TABLE sala;